const proxyConfig = require('@docmirror/mitmproxy/config.js')
module.exports = {
}
