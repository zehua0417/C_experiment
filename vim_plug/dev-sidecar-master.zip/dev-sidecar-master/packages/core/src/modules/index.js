const server = require('./server')

const proxy = require('./proxy')

const plugin = require('./plugin')

module.exports = {
  server,
  proxy,
  plugin
}
