// const config = require('../src/config')
//
// config.set({
//   server: {
//     intercepts: {
//       'github1.githubassets.com': {
//         '.*': {
//           redirect: 'assets.fastgit.org',
//           test: 'https://github.githubassets.com/favicons/favicon.svg',
//           desc: '静态资源加速'
//         }
//       },
//       'github.githubassets.com': null
//     }
//   }
// })
//
// console.log(config.get())
//
// config.reload()
